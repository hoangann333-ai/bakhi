package com.codegym.controller;

import com.codegym.dao.ProductDAO;
import com.codegym.model.Product;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;

@WebServlet(name = "ProductServlet", urlPatterns = {"/products"})
public class ProductServlet extends HttpServlet {
    private ProductDAO productDAO;

    @Override
    public void init() throws ServletException {
        String url = getServletContext().getInitParameter("jdbcURL");
        String username = getServletContext().getInitParameter("jdbcUsername");
        String password = getServletContext().getInitParameter("jdbcPassword");
        if (url == null || username == null || password == null) {
            throw new ServletException("Thiếu jdbcURL, jdbcUsername hoặc jdbcPassword trong web.xml");
        }
        productDAO = new ProductDAO(url, username, password);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        try {
            if ("new".equals(action)) {
                request.setAttribute("formAction", "create");
                request.getRequestDispatcher("/WEB-INF/views/product-form.jsp").forward(request, response);
                return;
            }
            if ("edit".equals(action)) {
                Product product = productDAO.findById(parseId(request.getParameter("id")));
                if (product == null) {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy sản phẩm.");
                    return;
                }
                request.setAttribute("product", product);
                request.setAttribute("formAction", "update");
                request.getRequestDispatcher("/WEB-INF/views/product-form.jsp").forward(request, response);
                return;
            }
            request.setAttribute("products", productDAO.findAll());
            request.setAttribute("success", request.getParameter("success"));
            request.getRequestDispatcher("/WEB-INF/views/product-list.jsp").forward(request, response);
        } catch (IllegalArgumentException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID sản phẩm không hợp lệ.");
        } catch (SQLException e) {
            throw new ServletException("Lỗi truy vấn cơ sở dữ liệu.", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        try {
            if ("delete".equals(action)) {
                int id = parseId(request.getParameter("id"));
                boolean deleted = productDAO.deleteById(id);
                redirectWithMessage(request, response, deleted ? "deleted" : "not-found");
                return;
            }
            if ("create".equals(action) || "update".equals(action)) {
                saveProduct(request, response, "update".equals(action));
                return;
            }
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Thao tác không hợp lệ.");
        } catch (IllegalArgumentException e) {
            request.setAttribute("error", e.getMessage());
            request.setAttribute("formAction", action);
            request.getRequestDispatcher("/WEB-INF/views/product-form.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException("Không thể lưu sản phẩm.", e);
        }
    }

    private void saveProduct(HttpServletRequest request, HttpServletResponse response, boolean update)
            throws ServletException, IOException, SQLException {
        String name = request.getParameter("name");
        String priceText = request.getParameter("price");
        String quantityText = request.getParameter("quantity");
        try {
            if (name == null || name.trim().isEmpty()) throw new IllegalArgumentException("Tên sản phẩm không được để trống.");
            BigDecimal price = new BigDecimal(priceText);
            int quantity = Integer.parseInt(quantityText);
            if (price.signum() < 0) throw new IllegalArgumentException("Giá phải lớn hơn hoặc bằng 0.");
            if (quantity < 0) throw new IllegalArgumentException("Số lượng phải lớn hơn hoặc bằng 0.");
            int id = update ? parseId(request.getParameter("id")) : 0;
            Product product = new Product(id, name.trim(), price, quantity);
            boolean saved = update ? productDAO.update(product) : productDAO.insert(product);
            if (!saved) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy sản phẩm để cập nhật.");
                return;
            }
            redirectWithMessage(request, response, update ? "updated" : "created");
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Giá và số lượng phải là số hợp lệ.");
        }
    }

    private int parseId(String value) {
        try {
            int id = Integer.parseInt(value);
            if (id < 1) throw new NumberFormatException();
            return id;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("ID sản phẩm không hợp lệ.");
        }
    }

    private void redirectWithMessage(HttpServletRequest request, HttpServletResponse response, String message)
            throws IOException {
        response.sendRedirect(request.getContextPath() + "/products?success=" + message);
    }
}

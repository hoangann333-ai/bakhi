<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Quản lý sản phẩm</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css">
</head>
<body>
<main class="container">
    <header class="topbar">
        <div><p class="eyebrow">FINAL EXAM · JSP / SERVLET / JDBC</p><h1>Quản lý sản phẩm</h1>
            <p class="subtitle">Danh sách sản phẩm được lưu trong MySQL.</p></div>
        <a class="primary-button" href="${pageContext.request.contextPath}/products?action=new">＋ Thêm sản phẩm</a>
    </header>
    <c:if test="${not empty success}">
        <div class="alert success">
            <c:choose>
                <c:when test="${success == 'created'}">Thêm sản phẩm thành công.</c:when>
                <c:when test="${success == 'updated'}">Cập nhật sản phẩm thành công.</c:when>
                <c:when test="${success == 'deleted'}">Xóa sản phẩm thành công.</c:when>
                <c:otherwise>Không tìm thấy sản phẩm cần xóa.</c:otherwise>
            </c:choose>
        </div>
    </c:if>
    <section class="panel">
        <div class="panel-heading"><div><h2>Danh sách sản phẩm</h2><p>Thông tin gồm ID, tên, giá và số lượng.</p></div>
            <span class="count"><c:out value="${products.size()}"/> sản phẩm</span></div>
        <div class="table-wrap"><table>
            <thead><tr><th>ID</th><th>Tên sản phẩm</th><th>Giá</th><th>Số lượng</th><th class="actions-heading">Thao tác</th></tr></thead>
            <tbody>
            <c:choose>
                <c:when test="${empty products}"><tr><td colspan="5" class="empty">Chưa có sản phẩm nào. Hãy thêm sản phẩm đầu tiên.</td></tr></c:when>
                <c:otherwise><c:forEach var="product" items="${products}">
                    <tr><td class="id-cell"><c:out value="${product.id}"/></td>
                        <td class="product-name"><c:out value="${product.name}"/></td>
                        <td><c:out value="${product.price}"/></td><td><c:out value="${product.quantity}"/></td>
                        <td><div class="row-actions">
                            <a class="edit-button" href="${pageContext.request.contextPath}/products?action=edit&amp;id=${product.id}">Sửa</a>
                            <form method="post" action="${pageContext.request.contextPath}/products" onsubmit="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?');">
                                <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="${product.id}">
                                <button class="delete-button" type="submit">Xóa</button>
                            </form>
                        </div></td>
                    </tr>
                </c:forEach></c:otherwise>
            </c:choose>
            </tbody>
        </table></div>
    </section>
    <footer>Product Management · Java Web MVC</footer>
</main>
</body>
</html>

<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title><c:choose><c:when test="${formAction == 'update'}">Sửa sản phẩm</c:when><c:otherwise>Thêm sản phẩm</c:otherwise></c:choose></title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css">
</head>
<body>
<main class="container form-container">
    <a class="back-link" href="${pageContext.request.contextPath}/products">← Quay lại danh sách</a>
    <section class="form-panel">
        <p class="eyebrow">PRODUCT INFORMATION</p>
        <h1><c:choose><c:when test="${formAction == 'update'}">Cập nhật sản phẩm</c:when><c:otherwise>Thêm sản phẩm mới</c:otherwise></c:choose></h1>
        <p class="subtitle">Nhập đầy đủ thông tin bên dưới.</p>
        <c:if test="${not empty error}"><div class="alert error"><c:out value="${error}"/></div></c:if>
        <form method="post" action="${pageContext.request.contextPath}/products" class="product-form">
            <input type="hidden" name="action" value="<c:out value='${formAction}'/>">
            <c:if test="${formAction == 'update'}"><input type="hidden" name="id" value="<c:out value='${product.id != null ? product.id : param.id}'/>"/></c:if>
            <label for="name">Tên sản phẩm</label>
            <input id="name" name="name" type="text" maxlength="150" required value="<c:out value='${product.name != null ? product.name : param.name}'/>" placeholder="Ví dụ: Bàn phím cơ">
            <label for="price">Giá (VNĐ)</label>
            <input id="price" name="price" type="number" min="0" step="0.01" required value="<c:out value='${product.price != null ? product.price : param.price}'/>" placeholder="0">
            <label for="quantity">Số lượng</label>
            <input id="quantity" name="quantity" type="number" min="0" step="1" required value="<c:out value='${product.quantity != null ? product.quantity : param.quantity}'/>" placeholder="0">
            <div class="form-buttons"><button class="primary-button" type="submit">Lưu sản phẩm</button>
                <a class="cancel-button" href="${pageContext.request.contextPath}/products">Hủy</a></div>
        </form>
    </section>
</main>
</body>
</html>

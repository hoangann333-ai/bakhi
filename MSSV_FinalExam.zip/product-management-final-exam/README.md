# Bài kiểm tra cuối module — Quản lý sản phẩm

Ứng dụng Java Web dùng JSP, Servlet, JDBC và MySQL. Project dùng Maven, Java 17, Jakarta Servlet 6, phù hợp Apache Tomcat 10.1+.

## 1. Chuẩn bị cơ sở dữ liệu
Mở `database.sql` trong MySQL Workbench và chạy toàn bộ script. Script tạo database `product_management`, bảng `products` và ba dòng sản phẩm mẫu.

## 2. Cấu hình kết nối
Mở `src/main/webapp/WEB-INF/web.xml`, thay `jdbcUsername` và `jdbcPassword` bằng tài khoản MySQL của bạn. Mặc định URL kết nối là `jdbc:mysql://localhost:3306/product_management`.

## 3. Đóng gói và chạy
Tại thư mục gốc project:

```bash
mvn clean package
```

Copy `target/product-management-final-exam.war` vào thư mục `webapps` của Tomcat 10.1+, khởi động Tomcat và mở:

```text
http://localhost:8080/product-management-final-exam/products
```

## Chức năng
- Hiển thị bảng sản phẩm từ MySQL.
- Thêm mới, cập nhật và xóa sản phẩm.
- Khi xóa, trình duyệt yêu cầu xác nhận trước khi gửi POST.
- DAO dùng `PreparedStatement`; giá sử dụng `DECIMAL`/`BigDecimal`.
- Servlet điều hướng request và JSP hiển thị giao diện.

## Cấu trúc mã nguồn
- `model/Product.java`: đối tượng sản phẩm.
- `dao/ProductDAO.java`: thao tác JDBC.
- `controller/ProductServlet.java`: xử lý request CRUD.
- `WEB-INF/views/`: JSP danh sách và form thêm/sửa.
- `database.sql`: tạo database, bảng và dữ liệu mẫu.

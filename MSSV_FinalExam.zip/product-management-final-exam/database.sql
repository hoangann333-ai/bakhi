CREATE DATABASE IF NOT EXISTS product_management
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE product_management;

CREATE TABLE IF NOT EXISTS products (
    id INT NOT NULL AUTO_INCREMENT,
    name VARCHAR(150) NOT NULL,
    price DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    quantity INT NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    CONSTRAINT chk_products_price CHECK (price >= 0),
    CONSTRAINT chk_products_quantity CHECK (quantity >= 0)
) ENGINE=InnoDB;

INSERT INTO products (name, price, quantity) VALUES
('Bàn phím cơ', 1290000.00, 15),
('Chuột không dây', 450000.00, 28),
('Màn hình 24 inch', 3290000.00, 8);
